<?php
namespace Smartcoin;

  class Installment extends \Smartcoin\Object {

  }
?>
