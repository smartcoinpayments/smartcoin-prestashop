<?php
  namespace Smartcoin;

  class Object_List extends \Smartcoin\Object {

  }
?>