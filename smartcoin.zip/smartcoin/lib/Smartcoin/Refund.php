<?php
namespace Smartcoin;

  class Refund extends \Smartcoin\Object {

  }
?>