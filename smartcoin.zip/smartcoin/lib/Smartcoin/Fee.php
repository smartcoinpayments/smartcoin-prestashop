<?php
namespace Smartcoin;

  class Fee extends \Smartcoin\Object {

  }
?>