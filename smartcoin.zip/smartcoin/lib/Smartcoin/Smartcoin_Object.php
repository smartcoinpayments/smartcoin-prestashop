<?php
namespace Smartcoin;

  class Smartcoin_Object extends \Smartcoin\Object {
  }
?>
