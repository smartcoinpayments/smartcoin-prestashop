<?php
namespace Smartcoin;

  class Card extends \Smartcoin\Object 
  {

  }
