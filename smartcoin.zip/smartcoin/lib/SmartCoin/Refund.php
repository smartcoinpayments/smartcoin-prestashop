<?php
  class Refund extends \SmartCoin\Object {

  }
?>