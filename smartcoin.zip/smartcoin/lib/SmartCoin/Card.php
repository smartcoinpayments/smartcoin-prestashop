<?php
  class Card extends \SmartCoin\Object {

  }
?>