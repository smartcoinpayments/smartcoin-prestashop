<?php
  class Installment extends \SmartCoin\Object {

  }
?>
