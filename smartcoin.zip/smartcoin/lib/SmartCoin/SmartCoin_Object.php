<?php
  class SmartCoin_Object extends \SmartCoin\Object {
  }
?>
