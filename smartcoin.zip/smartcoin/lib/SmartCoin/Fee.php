<?php
  class Fee extends \SmartCoin\Object {

  }
?>