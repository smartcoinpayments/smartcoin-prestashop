<?php
  namespace SmartCoin;

  class Object_List extends \SmartCoin\Object {

  }
?>