<?php
  require(dirname(__FILE__) . '/SmartCoin/Object.php');
  require(dirname(__FILE__) . '/SmartCoin/APIRequest.php');
  require(dirname(__FILE__) . '/SmartCoin/SmartCoin_Object.php');
  require(dirname(__FILE__) . '/SmartCoin/Token.php');
  require(dirname(__FILE__) . '/SmartCoin/Card.php');
  require(dirname(__FILE__) . '/SmartCoin/Refund.php');
  require(dirname(__FILE__) . '/SmartCoin/Fee.php');
  require(dirname(__FILE__) . '/SmartCoin/Installment.php');
  require(dirname(__FILE__) . '/SmartCoin/Charge.php');
  require(dirname(__FILE__) . '/SmartCoin/Object_List.php');
  require(dirname(__FILE__) . '/SmartCoin/Error.php');
  require(dirname(__FILE__) . '/SmartCoin/Util.php');
